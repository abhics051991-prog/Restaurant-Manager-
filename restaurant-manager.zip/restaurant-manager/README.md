# Restaurant Manager: Multi-Branch Inventory, Billing & Payroll

A single-page web app for running a restaurant business with several branches from one screen: stock, menu and recipes, billing with PDF invoices, suppliers, attendance, payroll and customers. Built with plain HTML, CSS and JavaScript. No framework, no build step, no backend.

![Dashboard](screenshots/01-dashboard.png)

## Features

| Module | What it does |
|---|---|
| **Dashboard** | Today's and this month's sales, sales per branch, low-stock alerts, supplier dues, staff present today |
| **Multi-branch stock** | Per-branch quantities for every product, minimum-stock alerts, stock adjustments (received / used / waste / recount), transfers between branches |
| **Menu & recipes** | Dishes with selling price and up to 5 ingredients per plate |
| **Billing** | Dish-based bills with GST (5/12/18%), payment mode, customer link. Stock is deducted automatically from the recipe, and restored if a bill is deleted |
| **PDF invoices** | Premium-styled invoice generated in the browser (canvas to PDF, no library). Download, or share via the phone's share sheet / WhatsApp |
| **Suppliers** | Purchases that increase stock, running dues, part-payments |
| **Staff & attendance** | Present / half day / absent per day, with a live monthly summary (days worked, absences, half days) |
| **Payroll** | Salary computed from attendance (pro-rated for the current month), bonus and deductions, one-click "record payment for all", salary slips, bank bulk-payment CSV |
| **Customers** | Visit count and total spend updated automatically from bills |
| **Exports** | Bills CSV, bank payment CSV, salary slips (printable HTML), invoice PDF |

## Screenshots

| Billing | Menu & recipes |
|---|---|
| ![Billing](screenshots/02-billing.png) | ![Menu](screenshots/03-menu.png) |

| Stock | Attendance |
|---|---|
| ![Stock](screenshots/04-stock.png) | ![Attendance](screenshots/07-attendance.png) |

| Payroll | Invoice PDF |
|---|---|
| ![Payroll](screenshots/08-payroll.png) | ![Invoice](screenshots/09-invoice-pdf.png) |

## Run it

No installation needed.

1. Download or clone this repository.
2. Open `index.html` in any modern browser.
3. Click **Load sample data** on the first screen to explore a ready-made 3-branch restaurant, or enter your own branch names and start fresh.

To host it online for free, push the folder to GitHub and enable **GitHub Pages** (Settings, Pages, deploy from the main branch).

## Tech notes

- **Vanilla JS, single file** (`index.html`). Responsive, works on phones.
- **Data layer:** a small Firestore-style adapter (`LocalDB`) over `localStorage`, using collections (`items`, `menu`, `bills`, `staff`, `att`, `pay`, `purch`, `sup`, `cust`) and `onSnapshot` subscriptions. Swapping it for Firebase or a REST API only means replacing that one object.
- **PDF invoices:** the invoice is drawn on a `<canvas>`, converted to JPEG and wrapped in a hand-built PDF (no external libraries), so the layout and fonts match the browser exactly.
- **Payroll logic:** `net = monthly salary × (days worked ÷ days in month) + bonus − deductions`. For the current month only days up to today are counted; days without an attendance entry count as present. Recorded payments are frozen so later changes do not alter them.
- **XSS-safe rendering:** all user text is escaped before it is inserted into the page.

## Limitations

- Data lives in one browser (`localStorage`), so it is not shared between devices. Multi-user sync needs a backend (Firebase, Supabase, etc.).
- The app records payments; it does not move money. The bank CSV is meant for bulk upload in your bank's net-banking portal, and every bank's template differs slightly.
- Sending an invoice straight to WhatsApp without a tap needs the WhatsApp Business API and a server.

## Roadmap ideas

- Backend sync and user roles (owner / branch manager / cashier)
- Menu-item images, QR code for UPI payment on the invoice
- Reports: daily sales trend, wastage analysis, supplier ledger
- Barcode scanning for stock counts

## License

MIT, see [LICENSE](LICENSE).
